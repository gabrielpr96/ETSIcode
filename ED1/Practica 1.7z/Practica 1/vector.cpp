#include "vector.h"


// METODO DE ORDENACION BURBUJA de una clase vector con los elementos en el atributo celda. Deber� adaptarlo a su problema/pr�ctica
/*
void vector::Burbuja(int inicio, int fin){
    int pos,ele;
    for (pos=inicio; pos<fin; pos++)
        for (ele=fin; ele>pos; ele--)
            if(celda[ele-1]>celda[ele])
                intercambiar(celda[ele-1],celda[ele]);//Funci�n gen�rica que tendr� que ser implementada
}
void intercambiar(int &a, int &b){
    a += b;
    b = a-b;
    a -= b;
}
*/
