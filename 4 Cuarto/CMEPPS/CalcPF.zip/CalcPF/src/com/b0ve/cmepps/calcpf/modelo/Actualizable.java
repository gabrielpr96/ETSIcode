package com.b0ve.cmepps.calcpf.modelo;

import java.io.Serializable;

public interface Actualizable {
    void actualizar();
}
